# WoCRM
Quản lí khách hàng
Phần mềm có bản quyền của wotech
Ai sao chép và sử dụng cho mục đích thương mại sẽ phải chịu mọi trách nhiệm về hành động của bản thân, tổ chức đó.
